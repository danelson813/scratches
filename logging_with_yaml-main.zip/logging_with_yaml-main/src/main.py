from helpers.using_YAML import loggerStartup


logger = loggerStartup()
logger.info("The logger module has started")

